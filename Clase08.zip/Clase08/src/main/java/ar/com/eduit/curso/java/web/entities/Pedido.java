package ar.com.eduit.curso.java.web.entities;

public class Pedido {
    private int id;
    private String fecha;
    private int idCliente;

    public Pedido() {
    }

    public Pedido(String fecha, int idCliente) {
        this.fecha = fecha;
        this.idCliente = idCliente;
    }

    public Pedido(int id, String fecha, int idCliente) {
        this.id = id;
        this.fecha = fecha;
        this.idCliente = idCliente;
    }

    @Override
    public String toString() {
        return "Pedido{" + "id=" + id + ", fecha=" + fecha + ", idCliente=" + idCliente + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
    
    
}
