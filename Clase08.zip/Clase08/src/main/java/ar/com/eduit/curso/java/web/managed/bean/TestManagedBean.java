package ar.com.eduit.curso.java.web.managed.bean;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named("xMB")
@SessionScoped
public class TestManagedBean implements Serializable {
    private int nro1=0;
    private int nro2=0;
    private int resultado=0;
    public String info(){
        return "Managed Bean Activo";
    }

    public void sumar(){
        resultado=nro1+nro2;
    }
    
    public int getNro1() {
        return nro1;
    }

    public void setNro1(int nro1) {
        this.nro1 = nro1;
    }

    public int getNro2() {
        return nro2;
    }

    public void setNro2(int nro2) {
        this.nro2 = nro2;
    }

    public int getResultado() {
        return resultado;
    }

    public void setResultado(int resultado) {
        this.resultado = resultado;
    }
    
    
}
