package ar.com.eduit.curso.java.web.test;

import java.util.Date;

public class TestFecha {
    public static void main(String[] args) {
        Date fecha=new Date("2020/10/03");
        System.out.println(fecha);
        String fecha2=(fecha.getYear()+1900)+"-"+(fecha.getMonth()+1)+"-"+(fecha.getDay()-3);
        System.out.println(fecha2);
    }
}
