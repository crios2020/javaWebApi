package ar.com.eduit.curso.java.web.repositories;

import ar.com.eduit.curso.java.web.connectors.ConnectorJDBC;
import ar.com.eduit.curso.java.web.entities.Detalle;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DetalleRepository {
    private Connection conn;
    public DetalleRepository(){
        conn=new ConnectorJDBC().getConnection();
    }
    public void save(Detalle detalle){
        if(detalle==null) return;
        try (PreparedStatement ps = conn.prepareStatement(
        "insert into detalles (idPedido,idArticulo,cantidad) values (?,?,?)",
        PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setInt(1, detalle.getIdPedido());
            ps.setInt(2, detalle.getIdArticulo());
            ps.setInt(3, detalle.getCantidad());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if(rs.next()) detalle.setId(rs.getInt(1));
        } catch (Exception e) {e.printStackTrace();}
    }
}
