package ar.com.eduit.curso.java.web.enums;
public enum TipoDocumento { DNI,LC,LE,PASS }