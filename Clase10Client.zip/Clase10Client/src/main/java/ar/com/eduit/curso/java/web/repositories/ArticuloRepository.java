package ar.com.eduit.curso.java.web.repositories;

import ar.com.eduit.curso.java.web.entities.Articulo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ArticuloRepository {

    private String url;

    public ArticuloRepository() {
        url = "http://localhost:8086/Clase10Server/resources/articulos/v1";
    }

    public ArticuloRepository(String url) {
        this.url = url;
    }

    public void save(Articulo articulo) {
        if(articulo==null) return;
        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest
                    .newBuilder()
                    .uri(URI.create(
                            url + "/alta?descripcion="+articulo.getDescripcion()
                            +"&precio="+articulo.getPrecio()
                            +"&stock="+articulo.getStock()
                            +"&stockMin="+articulo.getStockMin()
                            +"&stockMax="+articulo.getStock()
                    )).build();
            HttpResponse<String> response = client.send(request,
                    HttpResponse.BodyHandlers.ofString());
            int id=Integer.parseInt(response.body());
            articulo.setId(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Articulo> getAll() {
        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest
                    .newBuilder()
                    .uri(URI.create(url + "/all")).build();
            HttpResponse<String> response = client.send(request,
                    HttpResponse.BodyHandlers.ofString());
            Type listType = new TypeToken<List<Articulo>>() {
            }.getType();
            //System.out.println(response.body());
            List<Articulo> list = new Gson().fromJson(response.body(), listType);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<Articulo>();
        }
    }

    public List<Articulo> getLikeDescripcion(String descripcion) {
        if (descripcion == null) {
            return new ArrayList<Articulo>();
        }
        return getAll()
                .stream()
                .filter(a -> a.getDescripcion().toLowerCase().contains(descripcion.toLowerCase()))
                .collect(Collectors.toList());
    }

}
