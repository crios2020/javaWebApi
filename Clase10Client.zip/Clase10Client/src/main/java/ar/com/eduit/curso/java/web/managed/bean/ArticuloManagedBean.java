package ar.com.eduit.curso.java.web.managed.bean;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.ArticuloRepository;
import java.io.Serializable;
import java.sql.Connection;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
@Named("articuloMB")
@SessionScoped
public class ArticuloManagedBean implements Serializable{
    private ArticuloRepository ar=new ArticuloRepository();
    private String mensaje="";
    private Articulo articulo=new Articulo();
    private String buscarDescripcion="";
    
    public ArticuloManagedBean(){}
    
    public void save(){
        ar.save(articulo);
        if(articulo.getId()==0) mensaje="Ocurrio un error!";
        else mensaje="Se ingreso un articulo id:"+articulo.getId();
        articulo=new Articulo();
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage("Successful",  mensaje) );
    }
    
    public List<Articulo> getAll(){
        return ar.getAll();
    }
    
    public List<Articulo> getByDescripcion(){
        return ar.getLikeDescripcion(buscarDescripcion);
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public String getBuscarDescripcion() {
        return buscarDescripcion;
    }

    public void setBuscarDescripcion(String buscarDescripcion) {
        this.buscarDescripcion = buscarDescripcion;
    }
    
    
    
}