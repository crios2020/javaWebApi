package ar.com.eduit.curso.java.web.entities;
import ar.com.eduit.curso.java.web.enums.TipoDocumento;
public class Cliente {
    private int id;
    private String nombre;
    private TipoDocumento tipoDocumento;
    private String numeroDocumento;
    private String direccion;
    private String telefono;
    private String comentarios;

    public Cliente() {
    }

    public Cliente(String nombre, TipoDocumento tipoDocumento, String numeroDocumento, String direccion, String telefono, String comentarios) {
        this.nombre = nombre;
        this.tipoDocumento = tipoDocumento;
        this.numeroDocumento = numeroDocumento;
        this.direccion = direccion;
        this.telefono = telefono;
        this.comentarios = comentarios;
    }

    public Cliente(int id, String nombre, TipoDocumento tipoDocumento, String numeroDocumento, String direccion, String telefono, String comentarios) {
        this.id = id;
        this.nombre = nombre;
        this.tipoDocumento = tipoDocumento;
        this.numeroDocumento = numeroDocumento;
        this.direccion = direccion;
        this.telefono = telefono;
        this.comentarios = comentarios;
    }

    @Override
    public String toString() {
        return id + " "+ nombre + " " + tipoDocumento + " " + numeroDocumento + " " + direccion + " " + telefono + " " + comentarios;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }
  
}