package ar.com.eduit.curso.java.web.managed.bean;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.entities.Detalle;
import ar.com.eduit.curso.java.web.entities.Pedido;
import ar.com.eduit.curso.java.web.repositories.ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.DetalleRepository;
import ar.com.eduit.curso.java.web.repositories.PedidoRepository;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;


@Named("pedidoMB")
@SessionScoped
public class PedidoManagedBean implements Serializable{
    private PedidoRepository pr=new PedidoRepository();
    private DetalleRepository dr=new DetalleRepository();
    private ClienteRepository cr=new ClienteRepository();
    private Pedido pedido=new Pedido();
    private List<Detalle>listDetalles=new ArrayList();
    private Cliente cliente=new Cliente();
    private Articulo articulo1=new Articulo();
    private Articulo articulo2=new Articulo();
    private Articulo articulo3=new Articulo();
    private Articulo articulo4=new Articulo();
    private Articulo articulo5=new Articulo();
    private int cantidad1=0;
    private int cantidad2=0;
    private int cantidad3=0;
    private int cantidad4=0;
    private int cantidad5=0;
    private Date fecha=new Date();
    
    private String mensaje="";

    public PedidoManagedBean() {
    }
    
    public void save(){
        System.out.println("-------------------------------------------------");
        pedido.setFecha((fecha.getYear()+1900)+"-"+(fecha.getMonth()+1)+"-"+(fecha.getDay()-3));
        pedido.setIdCliente(cliente.getId());
        pr.save(pedido);
        if(cantidad1>0){
            Detalle detalle=new Detalle(pedido.getId(), articulo1.getId(), cantidad1);
            dr.save(detalle);
            System.out.println(detalle);
        }
        if(cantidad2>0){
            Detalle detalle=new Detalle(pedido.getId(), articulo2.getId(), cantidad2);
            dr.save(detalle);
            System.out.println(detalle);
        }
        if(cantidad3>0){
            Detalle detalle=new Detalle(pedido.getId(), articulo3.getId(), cantidad3);
            dr.save(detalle);
            System.out.println(detalle);
        }
        if(cantidad4>0){
            Detalle detalle=new Detalle(pedido.getId(), articulo4.getId(), cantidad4);
            dr.save(detalle);
            System.out.println(detalle);
        }
        if(cantidad5>0){
            Detalle detalle=new Detalle(pedido.getId(), articulo5.getId(), cantidad5);
            dr.save(detalle);
            System.out.println(detalle);
        }
        mensaje="se dio de alta pedido id: "+pedido.getId();
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage("Successful",  mensaje) );
        System.out.println("-------------------------------------------------");
        System.out.println(pedido);
        System.out.println(articulo1);
        System.out.println(articulo2);
        System.out.println(articulo3);
        System.out.println(articulo4);
        System.out.println(articulo5);
        System.out.println("-------------------------------------------------");
    }
    
    public List<Cliente>getAllClientes(){
        return cr.getAll();
    }
        
    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public List<Detalle> getListDetalles() {
        return listDetalles;
    }

    public void setListDetalles(List<Detalle> listDetalles) {
        this.listDetalles = listDetalles;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public Articulo getArticulo1() {
        return articulo1;
    }

    public void setArticulo1(Articulo articulo1) {
        this.articulo1 = articulo1;
    }

    public Articulo getArticulo2() {
        return articulo2;
    }

    public void setArticulo2(Articulo articulo2) {
        this.articulo2 = articulo2;
    }

    public Articulo getArticulo3() {
        return articulo3;
    }

    public void setArticulo3(Articulo articulo3) {
        this.articulo3 = articulo3;
    }

    public Articulo getArticulo4() {
        return articulo4;
    }

    public void setArticulo4(Articulo articulo4) {
        this.articulo4 = articulo4;
    }

    public Articulo getArticulo5() {
        return articulo5;
    }

    public void setArticulo5(Articulo articulo5) {
        this.articulo5 = articulo5;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public int getCantidad1() {
        return cantidad1;
    }

    public void setCantidad1(int cantidad1) {
        this.cantidad1 = cantidad1;
    }

    public int getCantidad2() {
        return cantidad2;
    }

    public void setCantidad2(int cantidad2) {
        this.cantidad2 = cantidad2;
    }

    public int getCantidad3() {
        return cantidad3;
    }

    public void setCantidad3(int cantidad3) {
        this.cantidad3 = cantidad3;
    }

    public int getCantidad4() {
        return cantidad4;
    }

    public void setCantidad4(int cantidad4) {
        this.cantidad4 = cantidad4;
    }

    public int getCantidad5() {
        return cantidad5;
    }

    public void setCantidad5(int cantidad5) {
        this.cantidad5 = cantidad5;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
    
    
    
}
