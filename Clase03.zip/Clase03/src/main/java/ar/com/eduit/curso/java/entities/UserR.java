package ar.com.eduit.curso.java.entities;
import java.util.ArrayList;
import java.util.List;
public class UserR {
    private List<User>list;
    public UserR(){
        list=new ArrayList();
        list.add(new User("juan","123","juan"));
        list.add(new User("ana","111","ana"));
        list.add(new User("jose","abc","jose"));
    }
    public List<User>getAll(){
        return list;
    }
    public void add(User user){
        list.add(user);
    }
}