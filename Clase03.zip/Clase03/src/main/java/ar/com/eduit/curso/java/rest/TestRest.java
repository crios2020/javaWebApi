package ar.com.eduit.curso.java.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

@Path("/testRest")
public class TestRest {
    
    @GET
    public String info(){
        return "Servicio REST TEST";
    }
    
    @GET
    @Path("/test")
    public String info2(){
        return "Curso Java WEB API";
    }
    
    @GET
    @Path("/calculadora")
    public String calculadora(@QueryParam("n1") int n1, @QueryParam("n2") int n2){
        int resultado=n1+n2;
        return resultado+"";
    }
}