package ar.com.eduit.curso.java.entities;
public class User {
    private String userName;
    private String pass;
    private String nombre;

    public User() {
    }

    public User(String userName, String pass, String nombre) {
        this.userName = userName;
        this.pass = pass;
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "User{" + "userName=" + userName + ", pass=" + pass + ", nombre=" + nombre + '}';
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
}