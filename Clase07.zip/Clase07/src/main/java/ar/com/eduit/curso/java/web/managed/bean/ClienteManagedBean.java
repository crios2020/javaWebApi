package ar.com.eduit.curso.java.web.managed.bean;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.enums.TipoDocumento;
import ar.com.eduit.curso.java.web.repositories.ClienteRepository;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named("clienteMB")
@SessionScoped
public class ClienteManagedBean implements Serializable{
    private ClienteRepository cr=new ClienteRepository();
    private Cliente cliente=new Cliente();
    private String mensaje="";
    private String buscarNombre="";
    private String buscarDireccion="";

    public ClienteManagedBean() {
    }

    public void save(){
        if(cliente.getNombre().length()<3){
            mensaje="La longitud del nombre debe tener al menos 3 caracteres!";
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("Successful",  mensaje) );
            return;
        }
        cr.save(cliente);
        if(cliente.getId()==0) mensaje="Ocurrio un error!";
        else mensaje="Se ingreso un cliente id:"+cliente.getId();
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage("Successful",  mensaje) );
        cliente=new Cliente();
    }
    
    public List<Cliente>getAll(){
        return cr.getAll();
    }
    
    public List<Cliente>getLikeNombreDireccion(){
        return cr.getLikeNombreDireccion(buscarNombre, buscarDireccion);
    }
    
    public List<TipoDocumento>getTipoDocumento(){
        return Arrays.asList(TipoDocumento.values());
    }
    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getBuscarNombre() {
        return buscarNombre;
    }

    public void setBuscarNombre(String buscarNombre) {
        this.buscarNombre = buscarNombre;
    }

    public String getBuscarDireccion() {
        return buscarDireccion;
    }

    public void setBuscarDireccion(String buscarDireccion) {
        this.buscarDireccion = buscarDireccion;
    }
    
    
    
}
