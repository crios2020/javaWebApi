package ar.com.eduit.curso.java.web.test;
import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.enums.TipoDocumento;
import ar.com.eduit.curso.java.web.repositories.ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.ClienteRepository;
public class TestRepositories {
    public static void main(String[] args) {
        ArticuloRepository ar=new ArticuloRepository();
        Articulo articulo=new Articulo("Remera", 2900, 40, 30, 80);
        ar.save(articulo);
        //System.out.println(articulo);
        ar.getAll().forEach(System.out::println);
        
        System.out.println("*************************************************");
        ClienteRepository cr=new ClienteRepository();
        //Cliente cliente=new Cliente("Laura", TipoDocumento.DNI, "12345633", "lavalle 648", "3232", "");
        //cr.save(cliente);
        
        //cr.getAll().forEach(System.out::println);
        cr.getLikeNombreDireccion("", "la").forEach(System.out::println);
    }
}