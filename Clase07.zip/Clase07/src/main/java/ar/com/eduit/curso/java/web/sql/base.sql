drop database if exists negocio;
create database negocio;
use negocio;
create table articulos(
    id int auto_increment primary key,
    descripcion varchar(25),
    precio float,
    stock int,
    stockMin int,
    stockMax int
);
create table clientes(
    id int auto_increment primary key,
    nombre varchar(25),
    tipoDocumento enum('DNI','LE','LC','PASS'),
    numeroDocumento char(8),
    direccion varchar(50),
    telefono varchar(20),
    comentarios varchar(255)
);
alter table clientes 
    add constraint UQ_clientesTipoNumero
    unique(tipoDocumento,numeroDocumento);

create table pedidos(
    id int auto_increment primary key,
    fecha date,
    idCliente int
);
alter table pedidos
    add constraint FK_pedidos_cliente
    foreign key (idCliente)
    references clientes(id);

create table detalles(
    id int auto_increment primary key,
    idPedido int not null,
    idArticulo int not null,
    cantidad int not null
);

alter table detalles
    add constraint FK_detalles_pedido
    foreign key(idPedido)
    references pedidos(id);

alter table detalles
    add constraint FK_detalles_articulo
    foreign key(idArticulo)
    references articulos(id);