package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.entities.Detalle;
import ar.com.eduit.curso.java.web.entities.Pedido;
import ar.com.eduit.curso.java.web.repositories.DetalleRepository;
import ar.com.eduit.curso.java.web.repositories.PedidoRepository;
import java.util.Date;


public class TestRepository2 {
    public static void main(String[] args) {
        PedidoRepository pr=new PedidoRepository();
        DetalleRepository dr=new DetalleRepository();
        Pedido pedido=new Pedido("2020/09/26", 1);
        Detalle detalle1=new Detalle(1,1,4);
        Detalle detalle2=new Detalle(1,3,5);
        Detalle detalle3=new Detalle(1,4,1);
        Detalle detalle4=new Detalle(1,5,1);
        
        pr.save(pedido);
        dr.save(detalle1);
        dr.save(detalle2);
        dr.save(detalle3);
        dr.save(detalle4);
        
        
        System.out.println(pedido);
        System.out.println(detalle1);
        System.out.println(detalle2);
        System.out.println(detalle3);
        System.out.println(detalle4);
        
    }
}