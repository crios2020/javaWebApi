package ar.com.eduit.curso.java.web.entities;
public class Detalle {
    private int id;
    private int idPedido;
    private int idArticulo;
    private int cantidad;

    public Detalle() {
    }

    public Detalle(int idPedido, int idArticulo, int cantidad) {
        this.idPedido = idPedido;
        this.idArticulo = idArticulo;
        this.cantidad = cantidad;
    }

    public Detalle(int id, int idPedido, int idArticulo, int cantidad) {
        this.id = id;
        this.idPedido = idPedido;
        this.idArticulo = idArticulo;
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return "Detalle{" + "id=" + id + ", idPedido=" + idPedido + ", idArticulo=" + idArticulo + ", cantidad=" + cantidad + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getIdArticulo() {
        return idArticulo;
    }

    public void setIdArticulo(int idArticulo) {
        this.idArticulo = idArticulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    
}