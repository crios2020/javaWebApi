package ar.com.eduit.curso.java.web.repositories;

import ar.com.eduit.curso.java.web.connectors.ConnectorJDBC;
import ar.com.eduit.curso.java.web.entities.Detalle;
import ar.com.eduit.curso.java.web.entities.Pedido;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PedidoRepository {
    private Connection conn;
    public PedidoRepository(){
        conn=new ConnectorJDBC().getConnection();
    }
    public void save(Pedido pedido){
        if(pedido==null) return;
        try (PreparedStatement ps = conn.prepareStatement(
        "insert into pedidos (fecha,idCliente) values (?,?)",
        PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, pedido.getFecha().toString());
            ps.setInt(2, pedido.getIdCliente());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if(rs.next()) pedido.setId(rs.getInt(1));
        } catch (Exception e) {e.printStackTrace();}
    }
}
