package ar.com.eduit.curso.java.web.managed.bean;

import ar.com.eduit.curso.java.web.entities.Detalle;
import ar.com.eduit.curso.java.web.entities.Pedido;
import ar.com.eduit.curso.java.web.repositories.DetalleRepository;
import ar.com.eduit.curso.java.web.repositories.PedidoRepository;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named("pedidoMB")
@SessionScoped
public class PedidoManagedBean implements Serializable{
    private PedidoRepository pr=new PedidoRepository();
    private DetalleRepository dr=new DetalleRepository();
    private Pedido pedido=new Pedido();
    private List<Detalle>listDetalles=new ArrayList();
    private String mensaje="";

    public PedidoManagedBean() {
    }
    
    public void save(){
        
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public List<Detalle> getListDetalles() {
        return listDetalles;
    }

    public void setListDetalles(List<Detalle> listDetalles) {
        this.listDetalles = listDetalles;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    
    
    
}
