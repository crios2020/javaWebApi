package ar.com.eduit.curso.java.web.api.clase03client;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

public class Client {
    public static void main(String[] args) throws Exception{
        //String url="http://localhost:8086/Clase03/UsuariosService";
        //String url="http://servicios.usig.buenosaires.gob.ar/normalizar?direccion=lavalle";
        //String url="http://localhost:8086/Clase03/CalculadoraService?n1=45&&n2=45";
        //String url="https://diycovid19mask.com/medMaskCore/geografia/barriosCABA/v1/";
        //String url="https://diycovid19mask.com/medMaskCore/entidades/usuarios/v1/all/";
        //String url="http://localhost:8086/Clase03/resources/testRest/calculadora?n1=84&n2=35";
        String url="http://localhost:8086/Clase03/resources/testRest";
       
        HttpClient client=HttpClient.newHttpClient();
        HttpRequest request=HttpRequest
                .newBuilder()
                .uri(URI.create(url)).build();
        HttpResponse<String> response=client.send(request, 
                HttpResponse.BodyHandlers.ofString());
        System.out.println(response.body());
        
        //Armar la lista de usuarios desde Json
        //Type listType = new TypeToken<List<User>>(){}.getType();
        //List<User> list=new Gson().fromJson(response.body(),listType);
        //list.forEach(System.out::println);
    }
}
