package ar.com.eduit.curso.java.web.rest;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.ArticuloRepository;
import com.google.gson.Gson;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

@Path("/articulos/v1")
public class ArticuloService {
    ArticuloRepository ar;

    public ArticuloService() {
        ar=new ArticuloRepository();
    }
    
    @GET
    public String info(){
        return "Servicio Articulo v1 activo";
    }
    @GET
    @Path("/all")
    public String getAll(){
        return new Gson().toJson(ar.getAll());
    }
    
    @GET
    @Path("/likeDescripcion")
    public String getLikeDescripcion(@QueryParam("descripcion") String descripcion){
        return new Gson().toJson(ar.getLikeDescripcion(descripcion));
    }
    
    @GET
    @Path("/alta")
    public String alta(@QueryParam("descripcion") String descripcion, 
                       @QueryParam("precio") float precio, 
                       @QueryParam("stock") int stock, 
                       @QueryParam("stockMax")int stockMax, 
                       @QueryParam("stockMin")int stockMin){
        Articulo articulo=new Articulo(descripcion, precio, stock, stockMin, stockMax);
        ar.save(articulo);
        return ""+articulo.getId();
    }
    @GET
    @Path("/baja")
    public String baja(@QueryParam("id")int id){
        try{
            ar.remove(ar.getById(id));
            return "true";
        }catch(Exception e){
            System.out.println("---------------------------------------------");
            e.printStackTrace();
            System.out.println("---------------------------------------------");
            return "false";
        }
    }
}
