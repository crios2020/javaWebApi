package ar.com.eduit.curso.java.web.test;
import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.ArticuloRepository;
public class TestRepositories {
    public static void main(String[] args) {
        ArticuloRepository ar=new ArticuloRepository();
        Articulo articulo=new Articulo("Remera", 2900, 40, 30, 80);
        ar.save(articulo);
        //System.out.println(articulo);
        //ar.getAll().forEach(System.out::println);
        ar.getLikeDescripcion("re").forEach(System.out::println);
    }
}