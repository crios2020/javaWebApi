use negocio;

select * from detalles;

select * from pedidos;

delete from pedidos where id=1;

select * from articulos;

update articulos set descripcion='' where descripcion is null;

