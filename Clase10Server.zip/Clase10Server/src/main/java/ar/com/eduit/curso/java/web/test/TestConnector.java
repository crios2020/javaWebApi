package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.connectors.ConnectorJDBC;
import java.sql.Connection;
import java.sql.ResultSet;

public class TestConnector {
    public static void main(String[] args) {
        try (Connection conn=new ConnectorJDBC().getConnection()){
            ResultSet rs=conn.createStatement().executeQuery("select version()");
            if(rs.next()) System.out.println(rs.getString(1));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}